package com.pertsol.ManageComments;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManageCommentsApplicationTests {

	@Test
	void contextLoads() {
	}

}
