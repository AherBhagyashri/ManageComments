package com.pertsol.ManageComments.Service;

import com.pertsol.ManageComments.Entities.Comment;
import com.pertsol.ManageComments.Repository.CommentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class CommentServiceImpl implements CommentService{

    @Autowired
    private CommentRepository commentRepository;


    @Override
    public Comment addComment(Comment comment) {
        return commentRepository.save(comment);
    }

    @Override
    public List<Comment> getAllComments() {
        return commentRepository.findAll();
    }

    @Override
    public List<Comment> getCommentsByUsername(String username) {
        return commentRepository.findByUsername(username);
    }

    @Override
    public List<Comment> getCommentsByDate(Date date) {
        return commentRepository.findByDateOfComment(date);
    }
}
