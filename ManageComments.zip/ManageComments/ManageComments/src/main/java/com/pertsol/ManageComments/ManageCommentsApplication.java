package com.pertsol.ManageComments;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ManageCommentsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ManageCommentsApplication.class, args);

		System.out.println("Manage commets app.......................");
	}

}
