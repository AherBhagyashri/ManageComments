package com.pertsol.ManageComments.Service;

import com.pertsol.ManageComments.Entities.Comment;
import java.util.Date;
import java.util.List;

public interface CommentService {

    Comment addComment(Comment comment);
    List<Comment> getAllComments();
    List<Comment> getCommentsByUsername(String username);
    List<Comment> getCommentsByDate(Date date);
}
