package com.pertsol.ManageComments.Entities;

import jakarta.persistence.*;

import java.util.Date;

@Entity
@Table(name = "Comments")
public class Comment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Long id;

    @Column(name = "username")
    private String username;

    @Column(name = "text")
    private String text;

    @Column(name = "dateofcomment")
    private Date dateOfComment;

    public Comment() {
    }

    public Comment(Long id, String username, String text, Date dateOfComment) {
        this.id = id;
        this.username = username;
        this.text = text;
        this.dateOfComment = dateOfComment;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public Date getDateOfComment() {
        return dateOfComment;
    }

    public void setDateOfComment(Date dateOfComment) {
        this.dateOfComment = dateOfComment;
    }

    @Override
    public String toString() {
        return "Comment{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", text='" + text + '\'' +
                ", dateOfComment=" + dateOfComment +
                '}';
    }
}
