package com.pertsol.ManageComments.Controller;


import com.pertsol.ManageComments.Entities.Comment;
import com.pertsol.ManageComments.Service.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/api/v2/comments")
public class CommentController {

    @Autowired
    private CommentService commentService;

    @PostMapping("/addcomment")
    public ResponseEntity<Comment> addComment(@RequestBody Comment comment) {
//        comment.setDateOfComment(new Date());
        return ResponseEntity.status(HttpStatus.CREATED).body(commentService.addComment(comment));
    }


    @GetMapping("/getAllComments")
    public ResponseEntity<List<Comment>> getAllComments() {
        return ResponseEntity.ok(commentService.getAllComments());
    }


    @GetMapping("/getCommentsByUsername/{username}")
    public ResponseEntity<List<Comment>>getCommentsByUsername(@PathVariable String username) {
        return ResponseEntity.ok(commentService.getCommentsByUsername(username));
    }


    @GetMapping("/getCommentsByDate/{date}")
    public ResponseEntity<List<Comment>> getCommentsByDate(@PathVariable String date) throws ParseException {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
        Date parsedDate = dateFormat.parse(date);
        return ResponseEntity.ok(commentService.getCommentsByDate(parsedDate));
    }
}
